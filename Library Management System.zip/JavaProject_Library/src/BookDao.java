import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.*;

public class BookDao { // inserting book details in the Books table
	
	public static int save(String callno,String name,String author,String publisher,int quantity){
		int status=0;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into books(callno,name,author,publisher,quantity) values(?,?,?,?,?)");
			ps.setString(1,callno);
			ps.setString(2,name);
			ps.setString(3,author);
			ps.setString(4,publisher);
			ps.setInt(5,quantity);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
}
public static int addbooks(String bcallno,int bquantity){ // updating the books
	int ret=0;
	try{
		Connection con=DB.getConnection();
		PreparedStatement prepS=con.prepareStatement("select quantity from books where callno=?");
		prepS.setString(1, bcallno);

	    ResultSet resS=prepS.executeQuery();  
		
	    int n=0, j=0;
	    while(resS.next()){ 
		int m=resS.getInt(1);
		if(m==0)j++; else n=m;
	    }
	    if(n!=0||j!=0)
	    {
		n=n+bquantity;
		PreparedStatement prepS2=con.prepareStatement("update books set quantity=? where callno=?");  
		prepS2.setInt(1,n);
		prepS2.setString(2,bcallno); 
		ret=prepS2.executeUpdate();}
	    
		con.close();
	}catch(Exception e){System.out.println(e);}
	return ret;
}
}
