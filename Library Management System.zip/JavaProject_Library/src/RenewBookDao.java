import java.sql.*;
import java.util.Date;
public class RenewBookDao {
	
public static boolean checkBook(String bookcallno){ // fetching books by call #
	boolean status=false;
	try{
		Connection con=DB.getConnection();
		PreparedStatement ps=con.prepareStatement("select * from books where callno=?");
		ps.setString(1,bookcallno);
	    ResultSet rs=ps.executeQuery();
		status=rs.next();
		con.close();
	}catch(Exception e){System.out.println("Exception: "+e);}
	return status;
}

public static int update(String bookcallno,int studentid, java.util.Date renewdate){ // renewing the book
	int status=0; 

	try{
		Connection con=DB.getConnection();
		

		PreparedStatement ps=con.prepareStatement("update issuebooks set duedate=? where bookcallno=? and studentid=?");
		ps.setDate(1, new java.sql.Date( renewdate.getTime()));
		ps.setString(2,bookcallno);
		ps.setInt(3,studentid);

		status=ps.executeUpdate();
		con.close();
	}catch(Exception e){System.out.println(e+" fbvhksd");}
	return status;
}
}